import { useEffect, useState } from 'react';
import EventForm from './components/EventForm';
import EventCard from './components/EventCard';
import RegistrationForm from './components/RegistrationForm';

const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';

function App() {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [message, setMessage] = useState('');

  const loadEvents = async () => {
    const response = await fetch(`${apiUrl}/events`);
    if (response.ok) {
      setEvents(await response.json());
    }
  };

  useEffect(() => {
    loadEvents();
  }, []);

  const handleEventCreated = async () => {
    await loadEvents();
    setMessage('Event saved successfully.');
    setTimeout(() => setMessage(''), 3000);
  };

  return (
    <div className="app-shell">
      <header>
        <h1>Church Event Management</h1>
        <p>Manage church events and attendee registrations with ease.</p>
      </header>

      {message && <div className="status-message">{message}</div>}

      <main>
        <section className="left-panel">
          <div className="card">
            <h2>Create New Event</h2>
            <EventForm apiUrl={apiUrl} onSuccess={handleEventCreated} />
          </div>

          <div className="card">
            <h2>Upcoming Events</h2>
            {events.length === 0 ? (
              <p>No events available yet.</p>
            ) : (
              events.map((event) => (
                <EventCard
                  key={event._id}
                  event={event}
                  onSelect={() => setSelectedEvent(event)}
                />
              ))
            )}
          </div>
        </section>

        <section className="right-panel">
          <div className="card">
            <h2>Register for an Event</h2>
            <RegistrationForm
              apiUrl={apiUrl}
              events={events}
              onSuccess={() => setMessage('Registration completed successfully.')}
            />
          </div>

          <div className="card">
            <h2>Selected Event</h2>
            {selectedEvent ? (
              <div>
                <h3>{selectedEvent.title}</h3>
                <p>{selectedEvent.description}</p>
                <p><strong>Date:</strong> {new Date(selectedEvent.date).toLocaleString()}</p>
                <p><strong>Location:</strong> {selectedEvent.location}</p>
                <p><strong>Capacity:</strong> {selectedEvent.capacity}</p>
              </div>
            ) : (
              <p>Select an event to view details.</p>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
