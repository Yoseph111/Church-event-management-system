import { useState } from 'react';

export default function RegistrationForm({ apiUrl, events, onSuccess }) {
  const [form, setForm] = useState({ eventId: '', name: '', email: '', phone: '', tickets: 1 });
  const [error, setError] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const response = await fetch(`${apiUrl}/registrations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });

    if (response.ok) {
      setForm({ eventId: '', name: '', email: '', phone: '', tickets: 1 });
      setError('');
      onSuccess();
    } else {
      const data = await response.json();
      setError(data.error || 'Registration failed.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="form-grid">
      <label>
        Event
        <select name="eventId" value={form.eventId} onChange={handleChange} required>
          <option value="">Select event</option>
          {events.map((event) => (
            <option key={event._id} value={event._id}>
              {event.title}
            </option>
          ))}
        </select>
      </label>
      <label>
        Full Name
        <input name="name" value={form.name} onChange={handleChange} required />
      </label>
      <label>
        Email
        <input type="email" name="email" value={form.email} onChange={handleChange} required />
      </label>
      <label>
        Phone
        <input name="phone" value={form.phone} onChange={handleChange} />
      </label>
      <label>
        Tickets
        <input type="number" name="tickets" value={form.tickets} min="1" onChange={handleChange} required />
      </label>
      {error && <div className="form-error">{error}</div>}
      <button type="submit">Submit Registration</button>
    </form>
  );
}
