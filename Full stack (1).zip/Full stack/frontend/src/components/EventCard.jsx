export default function EventCard({ event, onSelect }) {
  return (
    <article className="event-card" onClick={onSelect}>
      <h3>{event.title}</h3>
      <p>{new Date(event.date).toLocaleDateString()}</p>
      <p>{event.location}</p>
      <p>{event.capacity} seats</p>
    </article>
  );
}
