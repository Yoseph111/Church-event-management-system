import { useState } from 'react';

export default function EventForm({ apiUrl, onSuccess }) {
  const [form, setForm] = useState({
    title: '',
    date: '',
    location: '',
    description: '',
    capacity: 50,
  });
  const [error, setError] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const response = await fetch(`${apiUrl}/events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });

    if (response.ok) {
      setForm({ title: '', date: '', location: '', description: '', capacity: 50 });
      setError('');
      onSuccess();
    } else {
      const data = await response.json();
      setError(data.error || 'Unable to create event.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="form-grid">
      <label>
        Title
        <input name="title" value={form.title} onChange={handleChange} required />
      </label>
      <label>
        Date & Time
        <input type="datetime-local" name="date" value={form.date} onChange={handleChange} required />
      </label>
      <label>
        Location
        <input name="location" value={form.location} onChange={handleChange} required />
      </label>
      <label>
        Description
        <textarea name="description" value={form.description} onChange={handleChange} rows="4" required />
      </label>
      <label>
        Capacity
        <input type="number" name="capacity" value={form.capacity} min="1" onChange={handleChange} required />
      </label>
      {error && <div className="form-error">{error}</div>}
      <button type="submit">Save Event</button>
    </form>
  );
}
