# Technology Stack and Tools

## Backend
- JavaScript (Node.js)
- Express.js for HTTP API
- MongoDB with Mongoose ORM
- Swagger UI for API documentation
- dotenv for environment configuration
- cors for cross-origin requests

## Frontend
- React.js
- Vite for build and dev server
- Fetch API for backend requests
- CSS modules via plain CSS

## Tools
- Visual Studio Code
- Node.js / npm
- GitHub for source control and repository hosting
- Optional: MongoDB Atlas for deployment
