# Church Event Management System - Deployment Guide

## Step 1: Prepare GitHub Repository

### 1.1 Create a GitHub account (if you don't have one)
- Go to https://github.com
- Sign up

### 1.2 Create a new public repository
- Click **New Repository**
- Repository name: `church-event-management` (or your preference)
- **Description**: Church Event Management System with React frontend and Node backend
- **Public**: Select this option
- Click **Create repository**

### 1.3 Initialize and push your local code to GitHub

Open PowerShell in your project folder:

```powershell
cd "c:\Users\HP\OneDrive\Desktop\Full stack"

# Initialize git repo
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: Church Event Management System"

# Add remote origin (replace YOUR_USERNAME and YOUR_REPO)
git remote add origin https://github.com/YOUR_USERNAME/church-event-management.git

# Push to GitHub
git branch -M main
git push -u origin main
```

**Copy your repository URL** - you'll need it for Render and Vercel deployments.

---

## Step 2: Deploy Backend on Render

### 2.1 Create a Render account
- Go to https://render.com
- Sign up (use GitHub if available)

### 2.2 Connect GitHub to Render
- After login, go to **Dashboard**
- Click **+ New**
- Select **Web Service**
- Click **Connect account** → GitHub
- Authorize Render to access your GitHub repos
- Select your `church-event-management` repository

### 2.3 Configure the Web Service

**Name**: `church-event-management-backend`

**Branch**: `main`

**Root Directory**: `backend`

**Runtime**: `Node`

**Build Command**: `npm install`

**Start Command**: `npm start`

### 2.4 Add Environment Variables

Before deploying, add environment variables:
- Click **Environment**
- Add:
  - **Key**: `MONGO_URI`
  - **Value**: Your MongoDB Atlas connection string
    - If you don't have MongoDB Atlas:
      1. Go to https://www.mongodb.com/cloud/atlas
      2. Sign up (free tier available)
      3. Create a cluster
      4. Get connection string (looks like: `mongodb+srv://username:password@cluster.mongodb.net/dbname`)

**Optional**:
- **Key**: `PORT`
- **Value**: `4000`

### 2.5 Deploy
- Click **Deploy Web Service**
- Wait for deployment to complete (2-5 minutes)
- Once live, you'll see a URL like: `https://church-event-management-backend.onrender.com`

**Copy this backend URL** - you'll need it for the frontend.

### 2.6 Verify backend is running
- Visit: `https://your-render-url/api-docs` to see Swagger UI
- Example: `https://church-event-management-backend.onrender.com/api-docs`

---

## Step 3: Deploy Frontend on Vercel

### 3.1 Create a Vercel account
- Go to https://vercel.com
- Sign up (use GitHub if available)

### 3.2 Import your GitHub repository
- After login, click **Add New** → **Project**
- Click **Import Git Repository**
- Select your GitHub account
- Find and select `church-event-management` repo
- Click **Import**

### 3.3 Configure the project

**Project Settings**:
- **Framework Preset**: Select **React**
- **Root Directory**: Select `frontend`
- **Build and Output Settings** (should auto-detect):
  - **Build Command**: `npm install && npm run build`
  - **Output Directory**: `dist`
  - **Install Command**: `npm install`

### 3.4 Add Environment Variables
- Scroll to **Environment Variables**
- Add:
  - **Name**: `VITE_API_URL`
  - **Value**: `https://your-render-backend-url/api`
  - Example: `https://church-event-management-backend.onrender.com/api`

### 3.5 Deploy
- Click **Deploy**
- Wait for deployment (2-3 minutes)
- Once complete, you'll get a URL like: `https://church-event-management.vercel.app`

**Copy your frontend URL** - this is your live application.

---

## Step 4: Test the Deployed Application

### 4.1 Test frontend
- Open your Vercel frontend URL in browser
- Example: `https://church-event-management.vercel.app`
- Verify the interface loads

### 4.2 Test backend Swagger UI
- Open: `https://your-render-url/api-docs`
- Example: `https://church-event-management-backend.onrender.com/api-docs`
- You should see the interactive Swagger documentation

### 4.3 Test creating an event
- In the frontend, try creating an event
- Verify it appears in the list
- Check Swagger to confirm the API call was made

### 4.4 Test registration
- In the frontend, register for an event
- Verify success message
- Check that registrations persist

---

## Step 5: Troubleshooting

### Backend not starting on Render
- Check **Logs** in Render dashboard
- Most common issue: `MONGO_URI` not set
- Solution: Verify MongoDB connection string in Render environment variables

### Frontend showing blank page
- Check **Function Logs** in Vercel
- Verify `VITE_API_URL` is set correctly
- Ensure it points to your deployed backend (not localhost)

### API calls failing
- Open browser **DevTools** (F12) → **Network** tab
- Check if requests go to the correct backend URL
- Verify CORS is enabled (it should be by default)

### Swagger UI not loading
- Verify backend deployed successfully
- Check: `https://your-render-url/api-docs`
- If 404, the backend may not have started

---

## Step 6: Submit Your Project

### Collect these links:

1. **GitHub Repository URL**
   - Example: `https://github.com/YOUR_USERNAME/church-event-management`

2. **Frontend URL (Vercel)**
   - Example: `https://church-event-management.vercel.app`

3. **Backend Swagger URL (Render)**
   - Example: `https://church-event-management-backend.onrender.com/api-docs`

4. **Technology Stack Document**
   - Included in your repo at: `documentation/TECHNOLOGY_STACK.md`

### Submit to Google Classroom
- GitHub repo link
- Frontend deployed URL
- Backend Swagger URL
- Technology stack document link (from repo)

---

## Quick Reference: Your URLs

After deployment, fill in:
- **GitHub**: https://github.com/YOUR_USERNAME/church-event-management
- **Frontend**: https://your-vercel-domain.vercel.app
- **Backend API**: https://your-render-service.onrender.com
- **Swagger Docs**: https://your-render-service.onrender.com/api-docs

---

## Notes
- All deployments are **free** (with some limits on Render)
- Render free tier may sleep if unused for 15+ minutes (cold start)
- Vercel frontend has no sleep/cold start limitations
- MongoDB Atlas free tier: 512 MB storage, sufficient for testing
