# Church Event Management System

This workspace contains both backend and frontend code for a Church Event Management project.

## Structure
- `backend/` - Node.js + Express API with MongoDB and Swagger documentation.
- `frontend/` - React + Vite web application.
- `documentation/` - Technology stack summary.

## Setup
### Backend
1. Open terminal in `backend`
2. Install dependencies: `npm install`
3. Copy `.env.example` to `.env` and set `MONGO_URI`
4. Run backend: `npm run dev`

### Frontend
1. Open terminal in `frontend`
2. Install dependencies: `npm install`
3. Run frontend: `npm run dev`

## Notes
- Backend Swagger docs: `http://localhost:4000/api-docs`
- Frontend app: `http://localhost:5173`

## Render Deployment
1. Push the project to a public GitHub repository.
2. Add `render.yaml` at the repo root (already included).
3. On Render, create a new Web Service linked to the repo.
4. Render will use:
   - Build command: `cd backend && npm install`
   - Start command: `cd backend && npm start`
5. In Render service settings, add environment variables:
   - `MONGO_URI` = your MongoDB Atlas connection string
   - `PORT` = `4000` (optional, Render sets one automatically)
6. Deploy and copy the backend URL for your frontend environment variable.
