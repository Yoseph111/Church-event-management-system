const express = require('express');
const Event = require('../models/Event');
const Registration = require('../models/Registration');

const router = express.Router();

router.get('/', async (req, res) => {
  const events = await Event.find().sort({ date: 1 });
  res.json(events);
});

router.get('/:eventId', async (req, res) => {
  const event = await Event.findById(req.params.eventId);
  if (!event) return res.status(404).json({ error: 'Event not found' });
  res.json(event);
});

router.post('/', async (req, res) => {
  const { title, date, location, description, capacity } = req.body;
  if (!title || !date || !location || !description || !capacity) {
    return res.status(400).json({ error: 'All event fields are required' });
  }
  const event = new Event({ title, date, location, description, capacity });
  await event.save();
  res.status(201).json(event);
});

router.put('/:eventId', async (req, res) => {
  const event = await Event.findByIdAndUpdate(
    req.params.eventId,
    req.body,
    { new: true, runValidators: true }
  );
  if (!event) return res.status(404).json({ error: 'Event not found' });
  res.json(event);
});

router.delete('/:eventId', async (req, res) => {
  const event = await Event.findByIdAndDelete(req.params.eventId);
  if (!event) return res.status(404).json({ error: 'Event not found' });
  await Registration.deleteMany({ eventId: event._id });
  res.status(204).send();
});

router.get('/:eventId/registrations', async (req, res) => {
  const event = await Event.findById(req.params.eventId);
  if (!event) return res.status(404).json({ error: 'Event not found' });
  const registrations = await Registration.find({ eventId: req.params.eventId }).sort({ createdAt: -1 });
  res.json(registrations);
});

module.exports = router;
