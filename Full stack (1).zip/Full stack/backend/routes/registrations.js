const express = require('express');
const Registration = require('../models/Registration');
const Event = require('../models/Event');

const router = express.Router();

router.get('/', async (req, res) => {
  const registrations = await Registration.find().populate('eventId').sort({ createdAt: -1 });
  res.json(registrations);
});

router.post('/', async (req, res) => {
  const { eventId, name, email, phone, tickets } = req.body;
  if (!eventId || !name || !email || !tickets) {
    return res.status(400).json({ error: 'Event, name, email, and ticket count are required' });
  }

  const event = await Event.findById(eventId);
  if (!event) return res.status(404).json({ error: 'Event not found' });

  const totalRegistered = await Registration.aggregate([
    { $match: { eventId: event._id } },
    { $group: { _id: '$eventId', total: { $sum: '$tickets' } } }
  ]);

  const ticketsAlreadyBooked = (totalRegistered[0] && totalRegistered[0].total) || 0;
  if (ticketsAlreadyBooked + tickets > event.capacity) {
    return res.status(400).json({ error: 'Not enough capacity for this registration' });
  }

  const registration = new Registration({ eventId, name, email, phone, tickets });
  await registration.save();
  res.status(201).json(registration);
});

module.exports = router;
