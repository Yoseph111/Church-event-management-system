# Church Event Management System - Backend

## Overview
This backend provides a REST API for church events and registrations.
It includes:
- Event CRUD operations
- Registration creation and capacity checks
- Swagger documentation

## Tech Stack
- Node.js
- Express
- MongoDB / Mongoose
- Swagger UI
- dotenv

## Run locally
1. Copy `.env.example` to `.env` and set `MONGO_URI`.
2. Install dependencies:
   ```bash
   cd backend
   npm install
   ```
3. Start the server:
   ```bash
   npm run dev
   ```
4. Navigate to:
   - `http://localhost:4000`
   - `http://localhost:4000/api-docs`

## API Endpoints
- `GET /api/events`
- `POST /api/events`
- `GET /api/events/:eventId`
- `PUT /api/events/:eventId`
- `DELETE /api/events/:eventId`
- `GET /api/events/:eventId/registrations`
- `GET /api/registrations`
- `POST /api/registrations`
